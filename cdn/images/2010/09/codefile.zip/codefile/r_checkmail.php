<?php
include_once('./common.php');
checkclose();
if($_SCONFIG['allowrewrite'] && isset($_GET['rewrite'])) {
	$rws = explode('-', $_GET['rewrite']);
	if($rw_uid = intval($rws[0])) {
		$_GET['uid'] = $rw_uid;
	} else {
		$_GET['do'] = $rws[0];
	}
	if(isset($rws[1])) {
		$rw_count = count($rws);
		for ($rw_i=1; $rw_i<$rw_count; $rw_i=$rw_i+2) {
			$_GET[$rws[$rw_i]] = empty($rws[$rw_i+1])?'':$rws[$rw_i+1];
		}
	}
	unset($_GET['rewrite']);
}
$title	=	$_SCONFIG[sitename].'�����ַ��֤��';
$toemail=	$_GET['mail'];
if(!isemail($toemail)) {
	showmessage('email_format_is_wrong');
}
$query 	= 	$_SGLOBAL['db']->query("SELECT * FROM ".tname('checkusermail')." where mail='".$toemail."' and statu=1");
if($value 	= 	$_SGLOBAL['db']->fetch_array($query,1)) {
	showmessage('�����Ѿ���ע����');
}

$query 	= 	$_SGLOBAL['db']->query("SELECT * FROM ".tname('checkusermail')." where mail='".$toemail."' and statu=0");
if($value 	= 	$_SGLOBAL['db']->fetch_array($query,1)) {
	showmessage('��֤���Ѿ����ͳɹ��������ĵȴ�����');
}


$code	=	getCode (10,6);
$message=	'�����֤���ǣ�'.$code;
require("phpmailer/class.phpmailer.php"); 
$mail 	= new PHPMailer();
$mail->CharSet 	= "gbk"; 
$mail->FromName = $_SCONFIG[sitename];
$address 		= $toemail;
$mail->IsSMTP();
$mail->Host 	= "ssl://smtp.gmail.com";	//�ʼ�������
$mail->Port 	= "465";					//�ʼ��������˿�
$mail->SMTPAuth = true;
$mail->Username = "uchome8@gmail.com";		//�ʼ��ʺ�
$mail->Password = "123456789";				//�ʼ��ʺ�����
$mail->From 	= "uchome8@gmail.com";		//�����ʼ��ʺ�
$mail->AddAddress("$address", "");
$mail->Subject 	= $title;
$mail->MsgHTML($message);
$mail->IsHTML(true);
if($mail->Send()) {
	$data 	= 	array(
		"mail"			=> 	$toemail,
		"checknum"		=> 	$code,
		"dateline"		=> 	$_SGLOBAL['timestamp']
	);
	inserttable("checkusermail",$data);
	showmessage('���ͳɹ����뵽�������');
}
else
{
	showmessage('����ʧ��');
}

function getCode ($length = 32, $mode = 0) { 
	switch ($mode) { 
		case '1': 
			$str = '1234567890'; 
			break; 
		case '2': 
			$str = 'abcdefghijklmnopqrstuvwxyz'; 
			break; 
		case '3': 
			$str = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'; 
			break; 
		case '4': 
			$str = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'; 
			break; 
		case '5': 
			$str = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890'; 
			break; 
		case '6': 
			$str = 'abcdefghijklmnopqrstuvwxyz1234567890'; 
			break; 
		default: 
			$str = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890'; 
		break; 
	} 
	$randString = ''; 
	$len = strlen($str)-1; 
	for($i = 0;$i < $length;$i ++){ 
		$num = mt_rand(0, $len); 
		$randString .= $str[$num]; 
	} 
	return $randString ; 
} 
?>